def hello():
    print("Hello, from Gaumis!")